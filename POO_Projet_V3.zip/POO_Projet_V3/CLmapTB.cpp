//CLmap.CPP*****************************************************************************************
#include "CLmapTB.h"
#include <iostream>
namespace NS_Comp_Mappage
{
	String^ CLmapTB::Select(void)
	{
		return "SELECT [pp_id], [pp_nom], [pp_prenom] FROM [POO_Projet_V2].[dbo].[People]";
	}
	String^ CLmapTB::Insert(void)
	{
		return "INSERT INTO People (pp_nom, pp_prenom) VALUES('" + this->nom + "','" + this->prenom + "');";
	}
	String^ CLmapTB::Delete(void)
	{
		return "DELETE FROM People WHERE pp_id =" + "'" + this->Id + "';";
	}
	String^ CLmapTB::Update(void)
	{
		return "UPDATE People SET pp_nom = '" + this->nom + "', pp_prenom = '" + this->prenom + "' WHERE pp_id = " + "'" + this->Id + "';";

	}
	void CLmapTB::setId(int Id)
	{
		this->Id = Id;
	}
	void CLmapTB::setNom(String^ nom)
	{
		this->nom = nom;
	}
	void CLmapTB::setPrenom(String^ prenom)
	{
		this->prenom = prenom;
	}
	int CLmapTB::getId(void)
	{
		return this->Id;
	}
	String^ CLmapTB::getNom(void)
	{
		return this->nom;
	}
	String^ CLmapTB::getPrenom(void)
	{
		return this->prenom;
	}
}

