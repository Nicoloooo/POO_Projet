//CLservice.CPP***************************************************************************************"
#include "CLservices.h"

namespace NS_Comp_Svc
{
	CLservices::CLservices(void)
	{
		this->oCad = gcnew NS_Comp_Data::CLcad();
		this->oMappTB = gcnew NS_Comp_Mappage::CLmapTB();
	}
	DataSet^ CLservices::selectionnerToutesLesPersonnes(String^ dataTableName)
	{
		String^ sql;

		sql = this->oMappTB->Select();
		return this->oCad->getRows(sql, dataTableName);
	}
	void CLservices::ajouterUnePersonne(String^ nom, String^ prenom)
	{
		String^ sql;

		this->oMappTB->setNom(nom);
		this->oMappTB->setPrenom(prenom);
		sql = this->oMappTB->Insert();

		this->oCad->actionRows(sql);
	}
	void CLservices::supprimerUnePersonne(int id)
	{
		String^ sql;

		this->oMappTB->setId(id);
		sql = this->oMappTB->Delete();

		this->oCad->actionRows(sql);
	}

	void CLservices::mettreAjourUnePersonne(int id, String^ nom, String^ prenom)
	{
		String^ sql;

		this->oMappTB->setId(id);
		this->oMappTB->setNom(nom);
		this->oMappTB->setPrenom(prenom);
		sql = this->oMappTB->Update();

		this->oCad->actionRows(sql);
	}

}