//CLservice.h********************************************************************************
#pragma once
#include "CLmapTB.h"
#include "CLcad.h"

using namespace System;
using namespace Data;

namespace NS_Comp_Svc
{
	ref class CLservices
	{
	private:
		NS_Comp_Data::CLcad^ oCad;
		NS_Comp_Mappage::CLmapTB^ oMappTB;
	public:
		CLservices(void);
		DataSet^ selectionnerToutesLesPersonnes(String^);
		void ajouterUnePersonne(String^, String^);
		void supprimerUnePersonne(int);
		void mettreAjourUnePersonne(int, String^, String^);
	};
}