// CAD.H ***********************************************************************************
#pragma once

using namespace System;
using namespace Data;
using namespace SqlClient;

namespace NS_Comp_Data
{
	ref class CLcad
	{
	private:
		String^ sSql;
		String^ sCnx;
		SqlConnection^ oCnx;
		SqlCommand^ oCmd;
		SqlDataAdapter^ oDA;
		DataSet^ oDs;
	public:
		CLcad(void);
		DataSet^ getRows(String^, String^);
		void actionRows(String^);
	};
}