//CAD.CPP**************************************************************************************
#include "CLcad.h"

namespace NS_Comp_Data
{
	CLcad::CLcad(void)
	{
		this->sCnx = "Data Source=NICOFW-PORTABLE;Initial Catalog=POO_Projet_V1;User ID=POO_Projet_CNX;Password=azerty";

		this->sSql = "Rien";

		this->oCnx = gcnew SqlConnection(this->sCnx);
		this->oCmd = gcnew SqlCommand(this->sSql, this->oCnx);
		this->oDA = gcnew SqlDataAdapter();
		this->oDs = gcnew DataSet();

		this->oCmd->CommandType = CommandType::Text;
	}
	DataSet^ CLcad::getRows(String^ sSql, String^ sDataTableName)
	{
		this->oDs->Clear();
		this->sSql = sSql;
		this->oCmd->CommandText = this->sSql;
		this->oDA->SelectCommand = this->oCmd;
		this->oDA->Fill(this->oDs, sDataTableName);

		return this->oDs;
	}
	void CLcad::actionRows(String^ sSql)
	{
		this->sSql = sSql;
		this->oCmd->CommandText = this->sSql;
		this->oDA->SelectCommand = this->oCmd;
		this->oCnx->Open();
		this->oCmd->ExecuteNonQuery();
		this->oCnx->Close();
	}
}
