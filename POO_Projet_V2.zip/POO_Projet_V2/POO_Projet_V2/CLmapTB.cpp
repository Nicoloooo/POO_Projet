//CLmap.CPP*****************************************************************************************
#include "CLmapTB.h"

namespace NS_Comp_Mappage 
{
	String^ CLmapTB::Select(void)
	{
		return "SELECT [p_id], [p_nom], [p_prenom] FROM [POO_Projet_V1].[dbo].[Personnel]";
	}
	String^ CLmapTB::Insert(void)
	{
		return "INSERT INTO Personnel (p_nom, p_prenom) VALUES('" + this->nom + "','" + this->prenom + "');";
	}
	String^ CLmapTB::Delete(void)
	{
		return "DELETE FROM Personnel WHERE [p_id] =" + this->Id + ";";
	}
	String^ CLmapTB::Update(void)
	{
		return "";
	}
	void CLmapTB::setId(int Id)
	{
		this->Id = Id;
	}
	void CLmapTB::setNom(String^ nom)
	{
		this->nom = nom;
	}
	void CLmapTB::setPrenom(String^ prenom)
	{
		this->prenom = prenom;
	}
	int CLmapTB::getId(void) 
	{ 
		return this->Id; 
	}
	String^ CLmapTB::getNom(void) 
	{ 
		return this->nom; 
	}
	String^ CLmapTB::getPrenom(void) 
	{ 
		return this->prenom; 
	}
}

